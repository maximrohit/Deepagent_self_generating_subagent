"""
Central configuration for the self-evolving multi-agent system.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# All persisted sub-agents (LLM-generated AND hand-written) live here as .py files.
# This directory is what gets scanned on "warm boot".
SUB_AGENTS_DIR = BASE_DIR / "sub_agents"
SUB_AGENTS_DIR.mkdir(exist_ok=True, parents=True)

# Manifest = lightweight index of metadata (name/description/capabilities/file/hash).
# Kept separate from the .py files themselves so we can validate/inspect without
# importing (and therefore executing) code we don't need yet.
MANIFEST_PATH = SUB_AGENTS_DIR / "manifest.json"

# Model used for the supervisor's routing/evaluation decisions.
ROUTER_MODEL = os.environ.get("DEEP_AGENT_ROUTER_MODEL", "claude-sonnet-4-6")

# Model used when *writing* new sub-agent code (can be a stronger/coding-tuned model).
CODEGEN_MODEL = os.environ.get("DEEP_AGENT_CODEGEN_MODEL", "claude-opus-4-6")

# Default model new sub-agents themselves run on, unless the generated code overrides it.
SUB_AGENT_DEFAULT_MODEL = os.environ.get("DEEP_AGENT_SUBAGENT_MODEL", "claude-sonnet-4-6")
